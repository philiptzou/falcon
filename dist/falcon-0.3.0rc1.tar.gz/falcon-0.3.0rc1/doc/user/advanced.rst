.. Coming soon! sinks, serialization hooks, etc., server error stream, static file serving, file upload, etc.
.. if 'wsgi.file_wrapper' in environ:
.. multiple hooks per resource
.. after hooks
.. error responses for auth - 404 ?
.. error hooks
.. document all the individual error classes?
.. stacked hooks
.. auth whitelist
.. processing file uploads from forms
.. static file serving
.. wsgi middleware