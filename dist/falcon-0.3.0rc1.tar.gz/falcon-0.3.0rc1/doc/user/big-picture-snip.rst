The Big Picture
---------------

.. image:: ../_static/img/my-web-app.gif
    :alt: Falcon-based web application architecture
    :width: 600

|
